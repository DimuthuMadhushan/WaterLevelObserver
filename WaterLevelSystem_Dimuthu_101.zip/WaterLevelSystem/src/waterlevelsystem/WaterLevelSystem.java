/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package waterlevelsystem;

/**
 *
 * @author dimut
 */
public class WaterLevelSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        WaterLevelObservable waterLevelObservable=new WaterLevelObservable();
        waterLevelObservable.add((WaterLevelObserver)new NotificationWindow("Water Level",230,460,waterLevelObservable));
        waterLevelObservable.add((WaterLevelObserver)new NotificationWindow("Alarm",420,460,waterLevelObservable));
        waterLevelObservable.add((WaterLevelObserver)new NotificationWindow("SMS",610,460,waterLevelObservable));
        waterLevelObservable.add((WaterLevelObserver)new NotificationWindow("Splitter",800,460,waterLevelObservable));
        
        
    }
    
}
