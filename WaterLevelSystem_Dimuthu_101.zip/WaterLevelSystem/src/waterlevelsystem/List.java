/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package waterlevelsystem;


/**
 *
 * @author dimut
 */
class List <T>{
    private Node first;
    
    class Node {

        private T obj;
        private Node next;

        public Node(T  obj) {
            this.obj = obj;
        }
    }

    public boolean add(T obj) {
        Node nextNode = new Node(obj);
        if (first == null) {
            first = nextNode;

        } else {
            Node last = first;
            while (last.next != null) {
                last = last.next;
            }
            last.next = nextNode;
        }
        return true;
    }
        public boolean remove(T obj){
        int index=search(obj);
        return remove(index);
    }

    public void set(int index, T obj){ //replace
		
	}
	public int size(){
		int count=0;
		Node temp=first;
		while(temp!=null){
			temp=temp.next;
			count++;
		}
		return count;
	}
    public boolean add(int index, T obj) {
		if(index>=0 && index<=size()){
			Node nextNode = new Node(obj);
			if (index==0) {
				nextNode.next=first;
				first=nextNode;
			}else{
				Node temp = first;
				int count=0;
				while (count<index-1) {
					temp=temp.next;
					count++;
				}
				nextNode.next=temp.next;
				temp.next=nextNode;
			}
			return true;
		}
        return false;
    }
	public int search(T obj) {
        int index =-1;
        Node temp=first;
        while(temp!=null){
			index++;
			if(temp.obj.equals(obj)){
				return index;
			}
			temp=temp.next;
		}
        return -1;
    }
	public T get(int index) {
		if(index>=0 && index<size()){
			Node temp=first;
			int count=0;
			while(count!=index){
				temp=temp.next;
				count++;
			}
			return temp.obj;
		}
        return null;
    }
	public boolean remove(int index) {
        if(index>=0 && index<size()){
			if(index==0){
				first=first.next;
			}else{
				Node temp=first;
				int count=0;
				while(count<index-1){
					temp=temp.next;
					count++;
				}	
				temp.next=temp.next.next;
			}
			return true;
        }
        return false; 
    }
	    
    public String toString(){
		String list="{";
		Node temp=first;
		while(temp!=null){
			list+=temp.obj+", "; //toString()
			temp=temp.next;
		}
		return size()==0 ? "[empty]":list+"\b\b]";
	}
}


